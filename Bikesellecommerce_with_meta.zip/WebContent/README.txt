Carsell Ecommerce - Eclipse Dynamic Web Project

Instructions to import and run in Eclipse:
1. In MySQL: run the SQL file located at sql/schema.sql to create the database and sample data.
2. Ensure MySQL server is running and credentials match:
   username: root
   password: rahul@2004
   DB: ecommerce_db
3. In Eclipse:
   - File -> Import -> Existing Projects into Workspace -> Select archive file (carsellecommerce.zip) OR select root directory after unzipping.
   - Ensure the project is a Dynamic Web Project (Target runtime: Apache Tomcat).
4. Add MySQL JDBC driver to project:
   - Download MySQL Connector/J from dev.mysql.com and place the jar into WebContent/WEB-INF/lib
   - Or add it via Project -> Properties -> Java Build Path -> Libraries -> Add External JARs
5. Run on server (Tomcat). Access: http://localhost:8080/carsellecommerce/

Notes:
- Passwords are stored in plaintext in this sample for simplicity. For production, use a secure hash (BCrypt).
- This is a minimal demo to help you import and run quickly. Feel free to extend.
