package com.carsellecommerce.servlets;

import com.carsellecommerce.util.DBUtil;
import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CheckoutServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        Connection con = null;
        try {
            con = DBUtil.getConnection();
            con.setAutoCommit(false);

            // compute total from cart
            PreparedStatement ps = con.prepareStatement("SELECT p.price, c.quantity FROM cart c JOIN products p ON c.product_id=p.id WHERE c.user_id=?");
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            double total = 0;
            while (rs.next()) total += rs.getDouble("price") * rs.getInt("quantity");

            PreparedStatement insertOrder = con.prepareStatement("INSERT INTO orders (user_id, total, status) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            insertOrder.setInt(1, userId);
            insertOrder.setDouble(2, total);
            insertOrder.setString(3, "PLACED");
            insertOrder.executeUpdate();
            ResultSet gk = insertOrder.getGeneratedKeys();
            int orderId = -1;
            if (gk.next()) orderId = gk.getInt(1);

            // move cart items to order_items
            PreparedStatement cartItems = con.prepareStatement("SELECT product_id, quantity, (SELECT price FROM products WHERE id=c.product_id) as price FROM cart c WHERE c.user_id=?");
            cartItems.setInt(1, userId);
            ResultSet ci = cartItems.executeQuery();
            PreparedStatement insertItem = con.prepareStatement("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?,?,?,?)");
            while (ci.next()) {
                insertItem.setInt(1, orderId);
                insertItem.setInt(2, ci.getInt("product_id"));
                insertItem.setInt(3, ci.getInt("quantity"));
                insertItem.setDouble(4, ci.getDouble("price"));
                insertItem.executeUpdate();
            }

            // clear cart
            PreparedStatement clear = con.prepareStatement("DELETE FROM cart WHERE user_id=?");
            clear.setInt(1, userId);
            clear.executeUpdate();

            con.commit();
            response.sendRedirect("orderSuccess.jsp");
        } catch (Exception e) {
            if (con!=null) try{ con.rollback(); }catch(Exception ignored){}
            e.printStackTrace();
            response.sendRedirect("cart.jsp?error=1");
        } finally {
            if (con!=null) try{ con.close(); }catch(Exception ignored){}
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.sendRedirect("checkout.jsp");
    }
}
