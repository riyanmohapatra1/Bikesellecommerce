package com.carsellecommerce.servlets;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class ProductServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        RequestDispatcher rd = request.getRequestDispatcher("/products.jsp");
        rd.forward(request, response);
    }
}
