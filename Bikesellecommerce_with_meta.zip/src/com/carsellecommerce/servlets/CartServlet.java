package com.carsellecommerce.servlets;

import com.carsellecommerce.util.DBUtil;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.*;
import javax.servlet.http.*;

public class CartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        try (Connection con = DBUtil.getConnection()) {
            if ("add".equals(action)) {
                int productId = Integer.parseInt(request.getParameter("product_id"));
                int qty = Integer.parseInt(request.getParameter("quantity"));
                PreparedStatement ps = con.prepareStatement("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + ?");
                ps.setInt(1, userId);
                ps.setInt(2, productId);
                ps.setInt(3, qty);
                ps.setInt(4, qty);
                ps.executeUpdate();
            }
        } catch (Exception e) { e.printStackTrace(); }
        response.sendRedirect("cart.jsp");
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.sendRedirect("cart.jsp");
    }
}
